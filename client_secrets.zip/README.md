﻿item_catalog
to run it
1.write 'vagrant up'
2.write 'vagrant ssh'
3.inter to cd/ vagrant
4. write 'python data_base.py' to create tables in database
5.write 'python lotsofseries.py' to fill this tables
6.write 'python application.py' 
7.open browser "http://localhost:5000"

 
